
// PromptKeywordBox.tsx (이 행 삭제 금지)
import React from 'react';

interface PromptKeywordBoxProps {
  keywords: string[];
}

// 더 이상 화면에 보여줄 필요가 없으니 항상 null을 반환합니다.
const PromptKeywordBox: React.FC<PromptKeywordBoxProps> = (_props) => null;

export default PromptKeywordBox;
